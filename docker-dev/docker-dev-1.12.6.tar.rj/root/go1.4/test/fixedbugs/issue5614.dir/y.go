package y

import "./x"

var T = x.S

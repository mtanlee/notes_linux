// compiledir

// Copyright 2013 The Go Authors.  All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Using the same unexported name for a method as a method on an
// imported embedded type caused a gccgo compilation failure.

package ignored

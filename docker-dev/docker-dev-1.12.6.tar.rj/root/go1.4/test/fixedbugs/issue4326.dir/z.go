package z

import "./p2"

func main() {
	p2.NewO().RemoveOption("hello", "world")
}

package b

import "./a"

var foo = a.Bar

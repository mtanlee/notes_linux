package a

var Bar = func() (_ int) { return 0 }
